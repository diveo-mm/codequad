import * as vscode from 'vscode';
import * as path from 'path';

// ----------- 后端返回数据类型 -----------
interface CodeResponse {
    CodeResponse_code: string;
}

// 分析计划的接口（AI 返回结构）
interface PlanResponse {
    file?: string | null;
    start_line?: number;
    end_line?: number;
    new_code?: string;
    [key: string]: any;
}

// ----------- 调用后端接口 -----------
async function fetchFixCode(code: string): Promise<CodeResponse> {
    const response = await fetch('http://127.0.0.1:8000/fix_code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code })
    });
    const data = await response.json();
    return data as CodeResponse;
}

async function fetchCompleteCode(code: string): Promise<CodeResponse> {
    const response = await fetch('http://127.0.0.1:8000/complete_code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code })
    });
    const data = await response.json();
    return data as CodeResponse;
}

// ----------- 智能上下文提取函数 -----------
function getSmartContextWithMarker(
    editor: vscode.TextEditor,
    selection: vscode.Selection,
    contextLines: number = 3
): string {
    const doc = editor.document;
    const totalLines = doc.lineCount;
    let startLine = selection.start.line;
    let endLine = selection.end.line;
    const functionClassRegex = /^\s*(async\s+)?(function|def|class)\s+\w+/;

    for (let i = selection.start.line; i >= 0; i--) {
        const lineText = doc.lineAt(i).text;
        if (functionClassRegex.test(lineText)) {
            startLine = i;
            break;
        }
    }

    let openBraces = 0;
    let foundStart = false;
    for (let i = startLine; i < totalLines; i++) {
        const lineText = doc.lineAt(i).text;
        for (const char of lineText) {
            if (char === '{') { openBraces++; foundStart = true; }
            if (char === '}') openBraces--;
        }
        if (/^\s*(def |class )/.test(lineText) && i > startLine) {
            endLine = i - 1;
            break;
        }
        if (foundStart && openBraces <= 0) {
            endLine = i;
            break;
        }
    }

    startLine = Math.max(0, startLine - contextLines);
    endLine = Math.min(totalLines - 1, endLine + contextLines);

    let lines: string[] = [];
    for (let i = startLine; i <= endLine; i++) {
        let line = doc.lineAt(i).text;
        if (i === selection.start.line) line = `/* <<<<AI_TARGET_START>>>> */\n${line}`;
        if (i === selection.end.line) line = `${line}\n/* <<<<AI_TARGET_END>>>> */`;
        lines.push(line);
    }
    return lines.join('\n');
}

// ----------- 项目级上下文提取函数 -----------
async function getProjectContext(baseCode: string, currentDoc: vscode.TextDocument): Promise<string> {
    const contextPieces: string[] = [];
    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders) return baseCode;

    contextPieces.push(`/* ==== CURRENT FILE (${currentDoc.fileName}) ==== */\n${currentDoc.getText()}`);

    const classRegex = /\bnew\s+([A-Z][a-zA-Z0-9_]*)\s*\(/g;
    const importRegex = /\bimport\s+.*?([A-Z][a-zA-Z0-9_]+)\s*;/g;
    const usedClassNames = new Set<string>();

    let match;
    while ((match = classRegex.exec(baseCode)) !== null) usedClassNames.add(match[1]);
    while ((match = importRegex.exec(baseCode)) !== null) usedClassNames.add(match[1]);

    const directUseRegex = /\b([A-Z][a-zA-Z0-9_]+)\s*\./g;
    while ((match = directUseRegex.exec(baseCode)) !== null) usedClassNames.add(match[1]);

    for (const className of usedClassNames) {
        const pattern = `**/${className}.{java,py,ts,js}`;
        const foundFiles = await vscode.workspace.findFiles(pattern, '**/node_modules/**', 2);

        for (const file of foundFiles.slice(0, 1)) {
            const doc = await vscode.workspace.openTextDocument(file);
            const text = doc.getText();
            const classMatch = new RegExp(`(class\\s+${className}[^\\{]*\\{[\\s\\S]*?\\n\\})`, 'm').exec(text);
            const snippet = classMatch ? classMatch[1] : text.slice(0, 8000);
            contextPieces.push(`/* ==== RELATED CLASS: ${className} (${file.fsPath}) ==== */\n${snippet}`);
        }
    }

    const metaFiles = await vscode.workspace.findFiles('{package.json,requirements.txt}', '**/node_modules/**', 2);
    for (const file of metaFiles) {
        const doc = await vscode.workspace.openTextDocument(file);
        contextPieces.push(`/* ==== PROJECT META (${file.fsPath}) ==== */\n${doc.getText()}`);
    }

    const merged = contextPieces.join('\n\n');
    return merged.length > 20000 ? merged.slice(0, 20000) : merged;
}

// ----------- 插件激活 -----------
export function activate(context: vscode.ExtensionContext) {

    // ✅ 新增：AI对话智能修改命令（包含更可靠的类型/路径校验）
    const disposableWebview = vscode.commands.registerCommand('extension.aiChat', () => {
        const panel = vscode.window.createWebviewPanel(
            'aiChat', 'AI 代码助手', vscode.ViewColumn.One,
            { enableScripts: true,retainContextWhenHidden: true }
        );
        panel.webview.html = getWebviewContent();

        panel.webview.onDidReceiveMessage(async message => {
            // ---- 原有 sendCode（代码修复）逻辑 ----
            if (message.command === 'sendCode') {
                try {
                    const response = await fetchFixCode(message.code);
                    panel.webview.postMessage({
                        command: 'showResult',
                        fixedCode: response.CodeResponse_code || "⚠️ AI 没有返回任何内容"
                    });
                } catch (error) {
                    panel.webview.postMessage({ command: 'showResult', fixedCode: '调用后端失败: ' + String(error) });
                }
            }



        // ----------------- AI 聊天模式 -----------------
       if (message.command === 'sendAIChat') {
    try {
        const folders = vscode.workspace.workspaceFolders;
        let projectContext: Record<string, string> = {};

        if (folders && folders.length > 0) {
            const workspaceRoot = folders[0].uri.fsPath;
            const files = await vscode.workspace.findFiles(
                '**/*.{py,js,ts,java,go,cpp,cs}',
                '**/{node_modules,dist,build,__pycache__}/**',
                20
            );

            for (const file of files) {
                const doc = await vscode.workspace.openTextDocument(file);
                const text = doc.getText();
                projectContext[file.fsPath.replace(workspaceRoot + path.sep, '')] =
                    text.length > 4000 ? text.slice(0, 4000) + '\n/* ...省略... */' : text;
            }
        }

        // ✅ 发送给后端，包括上下文
        const res = await fetch('http://127.0.0.1:8000/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                project_context: projectContext,
                messages: [{ role: 'user', content: message.text }]
            })
        });

        interface ChatResponse {
            reply: string;
        }
        const data = (await res.json()) as ChatResponse;

        panel.webview.postMessage({
            command: 'showAIChatResult',
            userText: message.text,
            reply: data.reply
        });

    } catch (error) {
        panel.webview.postMessage({
            command: 'showAIChatResult',
            userText: message.text,
            reply: '调用后端失败: ' + String(error)
        });
    }
}



            // ✅ 新增：AI 对话 → 自动修改文件（带类型检查与路径解析）
            // ✅ 智能自动读取所有文件并发送上下文
if (message.command === 'sendChat') {
    try {
        const folders = vscode.workspace.workspaceFolders;
        if (!folders || folders.length === 0) {
            vscode.window.showErrorMessage("未打开任何工作区，无法分析项目。");
            return;
        }

        const workspaceRoot = folders[0].uri.fsPath;

        // 1️⃣ 获取项目中所有代码文件（排除node_modules）
        const files = await vscode.workspace.findFiles(
            '**/*.{py,js,ts,java,go,cpp,cs}',
            '**/{node_modules,dist,build,__pycache__}/**',
            30 // 限制最多30个文件，防止过大
        );

        // 2️⃣ 读取文件内容并限制长度
        const projectContext: Record<string, string> = {};
        for (const file of files) {
            const doc = await vscode.workspace.openTextDocument(file);
            const text = doc.getText();
            projectContext[file.fsPath.replace(workspaceRoot + path.sep, '')] =
                text.length > 8000 ? text.slice(0, 8000) + '\n/* ...省略... */' : text;
        }

        // 3️⃣ 发送请求给后端
        const res = await fetch('http://127.0.0.1:8000/analyze_and_edit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                project_context: projectContext,
                messages: [{ role: 'user', content: message.text }]
            })
        });

        // ✅ 显式声明 plan 的类型
        interface PlanResponse {
            file?: string;
            start_line?: number;
            end_line?: number;
            new_code?: string;
            explanation?: string;
        }

        const plan = (await res.json()) as PlanResponse;

        // 4️⃣ 判断返回是否合法
        if (!plan || !plan.file) {
            panel.webview.postMessage({
                command: 'showAIChatResult',
                userText: message.text,
                reply: `❌ 未能确定修改目标：${plan?.explanation || "无说明"}`
            });
            return;
        }

        // 5️⃣ 执行修改
        const absPath = path.isAbsolute(plan.file)
            ? plan.file
            : path.join(workspaceRoot, plan.file);
        const uri = vscode.Uri.file(absPath);
        const doc = await vscode.workspace.openTextDocument(uri);
        const editor = await vscode.window.showTextDocument(doc);

        const start = new vscode.Position(Math.max((plan.start_line ?? 1) - 1, 0), 0);
        const end = new vscode.Position(plan.end_line ?? start.line, 0);
        const newCode = plan.new_code || "";

        await editor.edit(editBuilder => {
            editBuilder.replace(new vscode.Range(start, end), newCode);
        });

        vscode.window.showInformationMessage(
            `✅ 已修改 ${plan.file}:${plan.start_line}-${plan.end_line}`
        );

        // 6️⃣ 回传到前端显示
        panel.webview.postMessage({
            command: 'showAIChatResult',
            userText: message.text,
            reply: `✅ 已修改文件 ${plan.file}\n💡 ${plan.explanation || "AI 无解释"}`
        });

    } catch (error: any) {
        panel.webview.postMessage({
            command: 'showAIChatResult',
            userText: message.text,
            reply: `❌ 处理失败：${String(error)}`
        });
    }
}

        });
    });
    // ----------- 修复选中代码（仅替换标记部分） -----------
    const disposableFixCode = vscode.commands.registerCommand('extension.fixSelectedCode', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) return vscode.window.showErrorMessage("请先打开一个文件！");
        const selection = editor.selection;
        if (!editor.document.getText(selection).trim()) return vscode.window.showErrorMessage("请先选中需要修复的代码！");

        const baseContext = getSmartContextWithMarker(editor, selection);
        const projectContext = await getProjectContext(baseContext, editor.document);
        const fullContext = baseContext + '\n\n/* ==== PROJECT CONTEXT ==== */\n' + projectContext;

        try {
            const data = await fetchFixCode(fullContext);
            const fixedCode = data.CodeResponse_code?.trim() || "⚠️ AI 没有返回任何内容";

            // ✅ 仅替换标记区域
            const startTag = '<<<<AI_TARGET_START>>>>';
            const endTag = '<<<<AI_TARGET_END>>>>';
            let toReplace = fixedCode;
            const startIdx = fixedCode.indexOf(startTag);
            const endIdx = fixedCode.indexOf(endTag);
            if (startIdx >= 0 && endIdx > startIdx) {
                toReplace = fixedCode.slice(startIdx + startTag.length, endIdx).trim();
            }

            await editor.edit(editBuilder => {
                editBuilder.replace(selection, toReplace);
            });

            vscode.window.showInformationMessage("✅ 代码已修复（仅替换选中部分）！");
        } catch (error) {
            vscode.window.showErrorMessage("调用后端失败: " + error);
        }
    });

    // ----------- 补全选中代码（仅替换标记部分） -----------
    const disposableCompleteCode = vscode.commands.registerCommand('extension.completeSelectedCode', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) return vscode.window.showErrorMessage("请先打开一个文件！");
        const selection = editor.selection;
        if (!editor.document.getText(selection).trim()) return vscode.window.showErrorMessage("请先选中需要补全的代码片段！");

        const baseContext = getSmartContextWithMarker(editor, selection);
        const projectContext = await getProjectContext(baseContext, editor.document);
        const fullContext = baseContext + '\n\n/* ==== PROJECT CONTEXT ==== */\n' + projectContext;

        try {
            const data = await fetchCompleteCode(fullContext);
            const completedCode = data.CodeResponse_code?.trim() || "⚠️ AI 没有返回任何内容";

            const startTag = '<<<<AI_TARGET_START>>>>';
            const endTag = '<<<<AI_TARGET_END>>>>';
            let toReplace = completedCode;
            const startIdx = completedCode.indexOf(startTag);
            const endIdx = completedCode.indexOf(endTag);
            if (startIdx >= 0 && endIdx > startIdx) {
                toReplace = completedCode.slice(startIdx + startTag.length, endIdx).trim();
            }

            await editor.edit(editBuilder => {
                editBuilder.replace(selection, toReplace);
            });

            vscode.window.showInformationMessage("✅ 代码已补全（仅替换选中部分）！");
        } catch (error) {
            vscode.window.showErrorMessage("调用后端失败: " + error);
        }
    });

    context.subscriptions.push(disposableWebview, disposableFixCode, disposableCompleteCode);
}

// ----------- 停用 -----------
export function deactivate() {}
// ----------- 统一模式 WebView 页面 -----------
function getWebviewContent() {
    return `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>CodeQuad AI</title>
<style>
body { font-family: sans-serif; padding: 10px; }
textarea { width: 100%; height: 120px; font-family: monospace; font-size: 14px; }
select, button { margin-top: 6px; padding: 6px 12px; font-size: 14px; }
#chatWindow { border: 1px solid #ccc; height: 300px; overflow-y: auto; padding: 10px; background: #f9f9f9; border-radius: 8px; margin-top: 10px; }
.message { margin-bottom: 10px; padding: 6px 10px; border-radius: 8px; max-width: 80%; }
.user { background-color: #d1eaff; align-self: flex-end; }
.ai { background-color: #f0f0f0; align-self: flex-start; }
.flex { display: flex; flex-direction: column; }
</style>
</head>
<body>
<h2>🤖 CodeQuad 智能代码助手</h2>

<label>选择模式：</label>
<select id="modeSelect">
    <option value="chat">🧠 智能理解并修改</option>
    <option value="aiChat">💬 AI 聊天模式</option>
</select>

<textarea id="inputArea" placeholder="请输入请求或代码..."></textarea>
<br>
<button id="sendBtn">发送给 AI</button>

<h3>AI 返回结果：</h3>
<div id="chatWindow" class="flex"></div>

<script>
const vscode = acquireVsCodeApi();

// 载入保存的状态（包含不同模式的历史）
window.addEventListener('load', () => {
    const saved = vscode.getState() || {};
    const mode = document.getElementById('modeSelect').value;
    loadHistoryForMode(mode, saved);
});

// 模式切换时自动刷新显示历史
document.getElementById('modeSelect').addEventListener('change', () => {
    const mode = document.getElementById('modeSelect').value;
    const saved = vscode.getState() || {};
    clearChatWindow();
    loadHistoryForMode(mode, saved);
});

// 发送消息按钮
document.getElementById('sendBtn').addEventListener('click', () => {
    const mode = document.getElementById('modeSelect').value;
    const text = document.getElementById('inputArea').value.trim();
    if (!text) return;

    if (mode === 'chat' || mode === 'aiChat') {
        appendMessage(mode, 'user', text);
    } else {
        document.getElementById('chatWindow').textContent = '⏳ AI 正在处理中...';
    }

    vscode.postMessage({
        command:
            mode === 'chat' ? 'sendChat' :
            mode === 'aiChat' ? 'sendAIChat' :
            'sendFix',
        text
    });

    document.getElementById('inputArea').value = '';
});

// 接收后端消息
window.addEventListener('message', event => {
    const msg = event.data;
    const mode = document.getElementById('modeSelect').value;

    if (msg.command === 'showResult' || msg.command === 'showChatResult') {
        document.getElementById('chatWindow').textContent = msg.result || msg.reply;
    }

    if (msg.command === 'showAIChatResult') {
        appendMessage(mode, 'ai', msg.reply);
    }
});

// ---------- 工具函数 ----------
function appendMessage(mode, role, text) {
    const container = document.getElementById('chatWindow');
    const div = document.createElement('div');
    div.className = 'message ' + (role === 'user' ? 'user' : 'ai');
    div.textContent = text;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;

    // 读取当前保存状态
    const current = vscode.getState() || { chatHistory: [], aiChatHistory: [] };

    // 根据模式保存不同历史
    if (mode === 'chat') {
        current.chatHistory.push({ role, text });
    } else if (mode === 'aiChat') {
        current.aiChatHistory.push({ role, text });
    }

    vscode.setState(current);
}

function loadHistoryForMode(mode, saved) {
    const history = mode === 'chat'
        ? (saved.chatHistory || [])
        : (saved.aiChatHistory || []);

    for (const msg of history) {
        appendMessage(mode, msg.role, msg.text);
    }
}

function clearChatWindow() {
    const container = document.getElementById('chatWindow');
    container.innerHTML = '';
}
</script>

</body>
</html>
`;
}
